console.log('Hello World!');
alert("what is ur name mate?");
console.log(alert);
